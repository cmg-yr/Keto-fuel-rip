document.addEventListener("DOMContentLoaded", () => {
  let form = document.getElementById('shippingform');
  form = !form ? document.querySelector('[name=prospect_form1]') : form;

  const setBillingForm = (event) => {
    if (event.target.value === 'no') {
      form = document.querySelector('.billing-info');
      const zipCode = form.querySelector('[name=billingZip]');
      const city = form.querySelector('[name=billingCity]');
      const state = form.querySelector('[name=billingState]');
      const country = form.querySelector('[name=billingCountry]');

      if (!!zipCode && !!city && !!state && !!country) {
        zipCode.addEventListener('change', (event) => {
          getGeoToForm(
            event.target.value,
            country.value,
            state,
            city
          );
        });
      }
    }
  };

  const billingSameCheckbox = [...document.getElementsByName('billingSameAsShipping')];
  if (!!billingSameCheckbox && !!billingSameCheckbox.length) {
    billingSameCheckbox.map(item => {
      item.addEventListener('change', setBillingForm);
      return item;
    });
  }

  if (!!form && !!form.shippingZip && !!form.shippingCountry && !!form.shippingState && !!form.shippingCity) {
    form.shippingZip.addEventListener('change', (event) => {
      getGeoToForm(
        event.target.value,
        form.shippingCountry.value,
        form.shippingState,
        form.shippingCity
      );
    });
  }
});

const getGeoToForm = (
  zipCodeValue,
  countryValue,
  stateSelector,
  cityField
) => {
  if (!!zipCodeValue && zipCodeValue.length >= 5 && !!countryValue) {
    jQuery.ajax({
      method: 'GET',
      url: `https://zip.getziptastic.com/v2/${countryValue}/${zipCodeValue}`,
      success: (data) => {
        stateSelector.value = data.state_short;
        cityField.value = data.city;
      },
      error: (error) => {
        console.log('Zip code search: ' + error.responseJSON.message);
        stateSelector.value = '';
        cityField.value = '';
      }
    });
  }
};